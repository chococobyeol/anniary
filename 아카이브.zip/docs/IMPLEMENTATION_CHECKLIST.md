# Anniary 구현 체크리스트

## 기술 스택 (확정)

| 구분 | 선택 | 버전 |
|------|------|------|
| Framework | React + TypeScript | React 19, TS 5.9 |
| Build | Vite | 6.x |
| 보드 렌더링 | SVG + CSS transforms | - |
| 상태 관리 | Zustand | 5.x |
| ID 생성 | nanoid | 5.x |
| 로컬 DB | Dexie (IndexedDB) | 4.x |
| 스타일링 | CSS Variables + CSS files | - |
| 모바일 패키징 | Capacitor (미래) | - |

---

## 완료된 항목

### 프로젝트 기반
- [x] Vite + React + TypeScript 프로젝트 셋업
- [x] 폴더 구조 설계 (`types`, `store`, `commands`, `components`, `hooks`, `utils`, `theme`)
- [x] 핵심 의존성 설치 (zustand, nanoid, dexie)

### 타입 시스템
- [x] 엔티티 타입 정의 (BoardEntity, ItemEntity, RangeEntity, OverlayEntity, AssetEntity)
- [x] 상태 타입 정의 (AppState, ViewState, PanelState, SelectionTarget)
- [x] 커맨드 타입 정의 (Board/Item/Range/Overlay CRUD commands)
- [x] 뷰모델 타입 정의 (DayCellViewModel, DayCellRenderPolicy)
- [x] 줌 레벨별 셀 표시 정책 매핑 (Z0~Z4)

### 상태 관리
- [x] Zustand store (useBoardStore)
- [x] Board CRUD (createBoard, setActiveBoard)
- [x] Item CRUD (createItem, updateItem, deleteItem)
- [x] Range CRUD (createRange, updateRange, deleteRange)
- [x] Overlay CRUD (createOverlay, updateOverlay, deleteOverlay)
- [x] View state (scale, translate, zoomLevel)
- [x] Panel state (left/right open/close, mode)
- [x] Interaction mode (pan/select/draw/place)
- [x] Selection state

### 테마 시스템
- [x] CSS custom properties 기반 테마 변수 정의
- [x] 색상, 타이포그래피, 간격, 상태 색상 전체 정의
- [x] 글로벌 스타일 리셋

### SVG 보드
- [x] YearBoard 컴포넌트 (12개월 세로 배치)
- [x] MonthRow 컴포넌트 (월별 가로 날짜 배열)
- [x] DayCell 컴포넌트 (개별 날짜 셀)
- [x] 날짜 레이아웃: 각 월이 한 줄, 1~31일 가로 연속 배열
- [x] 줌 레벨별 셀 정보 밀도 변화 (Z0~Z4)
- [x] Range marker 표시 (left band 방식, 최대 3개)
- [x] 상태 dot 표시
- [x] Progress bar 표시
- [x] Summary 텍스트 표시
- [x] Hidden count 표시
- [x] Today 하이라이트
- [x] 선택 상태 outline

### 줌/팬 시스템
- [x] 커스텀 useZoomPan 훅 (외부 라이브러리 없음)
- [x] 마우스 휠 줌 (Ctrl/Cmd + wheel → 커서 기준 줌)
- [x] 트랙패드 스크롤 (wheel → 팬)
- [x] 포인터 드래그 팬 (pan 모드)
- [x] 핀치 줌 (터치 2점)
- [x] 줌 범위 제한 (0.3x ~ 8x)
- [x] 줌 레벨 자동 판정 (셀 화면 폭 기준)

### 상단 툴바
- [x] 반투명 오버레이 툴바
- [x] Interaction mode 토글 (Pan/Select/Draw/Place)
- [x] 연도 표시
- [x] 줌 레벨 + 퍼센트 표시
- [x] 설정 버튼 → 우측 패널 토글

### 좌측 아이콘바 + 패널
- [x] 아이콘바 (Backlog, Search, Filter, Ranges, Overlays, Detail)
- [x] 좌측 패널 overlay 방식 (보드 크기 변경 없음)
- [x] Backlog 패널 (item 생성, 상태 토글, 삭제)
- [x] Detail 패널 (선택된 날짜 상세 표시)
- [x] 모드별 패널 전환

### 우측 패널
- [x] 시스템 패널 기본 구조 (settings, account, sync, export 등)
- [x] overlay 방식, 닫기 버튼

### 기본 기능
- [x] ESC로 전체 패널 닫기
- [x] 앱 시작 시 자동 보드 생성 (현재 연도)

### v1.1 패치 (2026-03-17)
- [x] 뷰 초기화(Fit to screen) 버튼 추가 — 상단 툴바에 모드 그룹 옆 배치
- [x] 첫 진입 시 전체 달력이 화면에 맞도록 자동 fit (resetView)
- [x] 요일 표시 헤더 (DayOfWeekHeader) — 보드 상단에 S/M/T/W/T/F/S, 일요일 빨강, 토요일 파랑
- [x] 모든 아이콘을 이모지 → SVG 벡터 아이콘으로 교체 (Icons.tsx, 17개 아이콘)
- [x] 한글(macOS) 이중 입력 버그 수정 — `isComposing` 체크 적용
- [x] 메모 입력 개선 — 크기 조절 가능한 textarea, 마크다운 힌트, Enter/Shift+Enter 구분
- [x] Backlog item에 body(메모) 필드 지원

### v1.2 패치 (2026-03-17)
- [x] **wheel passive listener 수정** — React `onWheel`(passive) → `useEffect` + `addEventListener({ passive: false })`로 변경. 스크롤/줌 시 렉 제거.
- [x] **팬 아이콘 수정** — 복잡한 Hand SVG → 단순 Move(십자 화살표) 아이콘으로 교체. `IconMove` 추가.
- [x] **요일 표시 완전 재설계** — 공유 헤더(1월 기준) 방식 폐기 → 각 셀에 실제 요일 표시. `DayCellViewModel`에 `dayOfWeek`, `dayOfWeekLabel`, `isWeekend` 추가. `DayOfWeekHeader.tsx` 삭제.
- [x] **주말 시각 구분** — 주말 셀 배경색(`--bg-cell-weekend`), 일요일/토요일 날짜 숫자 색상 구분
- [x] **백로그 done 아이템 관리** — done 상태 아이템이 즉시 사라지지 않고 "완료됨" 접이식 섹션에 표시
- [x] **백로그 긴 내용 확장** — 아이템 클릭 시 전체 body 내용 펼침/접기 (expand/collapse)
- [x] **아이콘 추가** — `IconChevronDown`, `IconChevronUp`, `IconCheck` 추가 (총 20개)

### v1.3 패치 (2026-03-17)
- [x] **setState-during-render 버그 수정** — `useBoardStore.setState()` 렌더 중 호출 → module-level `fitToScreenRef` 방식으로 변경. 무한 재렌더링 루프 및 렉 완전 제거.
- [x] **줌 기능 정상화** — 위 버그가 원인. 재렌더링 폭풍이 wheel 핸들러를 무력화했음. setState 제거 후 Ctrl/Cmd+wheel 줌 정상 동작.
- [x] **상태 토글 1클릭** — 기존 3단계(none→in-progress→done) 순환에서 1클릭 토글(none↔done)로 변경.

### v1.4 패치 (2026-03-17)
- [x] **wheel 리스너 미등록 수정** — early return으로 containerRef가 null인 상태에서 useEffect 실행 → 리스너 미등록. container div를 항상 렌더하도록 수정.

### v1.5 기능 추가 (2026-03-17)
- [x] **요일 표시 2가지 모드** — `linear`(셀 내 요일 표시) + `weekday-aligned`(상단 헤더 + 요일별 열 정렬). 설정에서 전환 가능.
- [x] **요일 3글자** — S/M/T/W/T/F/S → SUN/MON/TUE/WED/THU/FRI/SAT
- [x] **줌 방향 설정** — 기본값: 휠 아래=확대. `zoomInverted` 설정으로 반전 가능.
- [x] **설정 패널 구현** — 우측 패널 settings 모드에 레이아웃/줌 설정 UI 추가. 토글 스위치, 셀렉트 박스.
- [x] **AppSettings 타입** — `dayLayout: 'linear' | 'weekday-aligned'`, `zoomInverted: boolean` 추가.
- [x] **WeekdayHeader 컴포넌트** — weekday-aligned 모드용 상단 요일 헤더. 열 수는 해당 연도 기준 동적 계산.
- [x] **레이아웃 전환 시 자동 fitToScreen** — dayLayout 변경 시 보드를 화면에 맞춤.

### v2.0 — 편집 흐름 구축 (2026-03-17)
- [x] **날짜 인덱싱 최적화** — `Object.values().filter()` 제거. `buildItemDateIndex` / `buildRangeDateIndex`로 사전 인덱싱 후 O(1) 조회. `src/utils/indexing.ts` 신규.
- [x] **셀 선택 → DetailPanel 자동 오픈** — pan/select 모드에서 셀 클릭 시 해당 날짜 선택 + detail 패널 자동 오픈.
- [x] ~~**더블클릭 quick add**~~ → **더블클릭 셀 확장**으로 변경 (v2.1). 빈 task 자동 생성 제거, 더블클릭 시 해당 셀이 확장되어 항목 목록 표시.
- [x] **DetailPanel 편집기 승격** — 읽기 전용 → 실제 편집기로 변환:
  - 날짜별 item 추가 (kind 선택 + 제목 입력)
  - item 인라인 편집 (제목/메모 수정)
  - 상태 토글 (none ↔ done)
  - 백로그로 이동 (날짜 해제)
  - 삭제
- [x] **Interaction mode 규칙 확정**:
  - `pan`: 드래그=이동, 클릭=셀 선택+편집
  - `select`: 클릭=셀 선택+편집, 드래그=날짜 범위 선택 (예정)
  - `draw`: 드래그=range 생성 (예정)
  - `place`: 클릭=overlay 배치 (예정)

### v2.1 — 셀 UX 개선 (2026-03-17)
- [x] **셀 높이 증가** — `BASE_CELL_HEIGHT` 22→28. 세로 여유 확보, 내부 요소 y좌표 재배치.
- [x] **더블클릭 빈 task 생성 제거** — 불필요한 빈 task 자동 생성 동작 삭제.
- [x] **더블클릭 셀 확장** — 더블클릭 시 해당 셀 위치에 확장 카드(ExpandedCell) 오버레이 표시. 날짜/요일/아이템 목록 표시. 같은 셀 재더블클릭, ✕ 버튼, Escape, 다른 셀 클릭으로 닫힘.
- [x] **ExpandedCell 컴포넌트 신규** — `src/components/board/ExpandedCell.tsx`. SVG 오버레이 방식, 폭 4배 확장, 높이는 아이템 수에 따라 자동 조절.

---

## 미구현 항목 (다음 작업 순서)

### Phase 2 — 핵심 인터랙션
- [x] 셀 클릭 → 좌측 DetailPanel 자동 오픈 (pan/select 모드)
- [x] 셀 더블클릭 → 셀 확장 (항목 목록 인라인 표시)
- [ ] 날짜 드래그 선택 → range 생성
- [ ] Context menu (우클릭 / long press)
- [ ] Range 선택 및 하이라이트
- [ ] Overlay 선택/이동/리사이즈
- [ ] 키보드 단축키 (1=pan, 2=select, 3=draw, 4=place)

### Phase 3 — 패널 내부 완성
- [ ] Detail 패널 — item 상세 편집 (title, body, status, progress, date, range)
- [ ] Detail 패널 — range 상세 편집
- [ ] Detail 패널 — overlay 속성 편집
- [ ] Search 패널 — 전체 검색
- [ ] Filter 패널 — view filter
- [ ] Ranges 패널 — range 목록 관리
- [ ] Overlays 패널 — overlay 목록 관리
- [ ] Layers 패널 — 레이어 show/hide

### Phase 4 — 저장/동기화
- [ ] IndexedDB (Dexie) 연동
- [ ] Autosave (debounce)
- [ ] Dirty flag 기반 저장
- [ ] Board load/save 흐름
- [ ] Multi-board 지원
- [ ] Migration 구조

### Phase 5 — Export/Import
- [ ] JSON full backup export
- [ ] JSON import (replace/merge)
- [ ] ICS export
- [ ] ICS import
- [ ] PNG high-resolution export
- [ ] Selection export
- [ ] Layer export

### Phase 6 — 시각 요소
- [ ] Overlay/Sticker 시스템 완성
  - [ ] 스티커 생성/배치
  - [ ] 텍스트 오버레이
  - [ ] 이미지 업로드
  - [ ] Shape 오버레이
  - [ ] Anchor 시스템 (none/month/day/range)
  - [ ] Lock/Unlock
  - [ ] 줌 단계별 존재감 조절
- [ ] Range 시각 완성
  - [ ] Range progress bar
  - [ ] Range 상태별 색상 변화
  - [ ] Range label 줌별 표시
- [ ] 주(week) 구분선 (선택적 UI)
- [ ] 월 헤더 디자인 개선

### Phase 7 — 테마/설정
- [ ] 다크 모드
- [ ] 테마 커스터마이징 UI (설정 패널)
- [ ] 폰트 변경
- [ ] 색상 팔레트 변경
- [ ] 주 시작 요일 설정

### Phase 8 — 모바일 최적화
- [ ] 터치 제스처 충돌 해결 (pinch vs pan vs select)
- [ ] 모바일 패널 전체 폭 확장
- [ ] Long press 메뉴
- [ ] Double tap 줌

### Phase 9 — 고급 기능
- [ ] Undo/Redo
- [ ] Command log
- [ ] 동기화 구조 (version, conflict)
- [ ] Google Drive 백업
- [ ] 로그인/세션 유지
- [ ] Toast 알림 시스템

### Phase 10 — AI/MCP 대응
- [ ] Command 구조를 external API로 노출
- [ ] MCP server 구조
- [ ] JSON 입력 기반 command 실행

---

## 파일 구조

```
src/
├── App.tsx                     # 메인 레이아웃
├── App.css
├── main.tsx                    # 엔트리 포인트
├── types/
│   ├── entities.ts             # 5개 엔티티 타입
│   ├── state.ts                # AppState, ViewState, PanelState
│   ├── commands.ts             # 커맨드 타입 정의
│   ├── view-models.ts          # DayCellViewModel, 줌 정책
│   └── index.ts
├── store/
│   └── board-store.ts          # Zustand store + command actions
├── hooks/
│   └── useZoomPan.ts           # 줌/팬 커스텀 훅
├── utils/
│   ├── date.ts                 # 날짜 유틸리티
│   ├── zoom.ts                 # 줌 레벨 계산, 상수
│   ├── indexing.ts             # 날짜 인덱싱 유틸
│   └── id.ts                   # nanoid 래퍼
├── theme/
│   ├── theme.css               # CSS 변수 정의
│   └── global.css              # 글로벌 리셋
└── components/
    ├── board/
    │   ├── YearBoard.tsx        # 메인 보드
    │   ├── YearBoard.css
    │   ├── MonthRow.tsx         # 월별 행 (linear/aligned 레이아웃 지원)
    │   ├── DayCell.tsx          # 날짜 셀 (요일 표시 포함)
    │   ├── ExpandedCell.tsx    # 더블클릭 확장 셀 오버레이
    │   └── WeekdayHeader.tsx    # weekday-aligned 모드 상단 요일 헤더
    ├── icons/
    │   └── Icons.tsx            # SVG 벡터 아이콘 모음
    ├── toolbar/
    │   ├── TopToolbar.tsx       # 상단 도구 모음
    │   └── TopToolbar.css
    └── panels/
        ├── LeftIconBar.tsx      # 좌측 아이콘바
        ├── LeftIconBar.css
        ├── LeftPanel.tsx        # 좌측 작업 패널
        ├── LeftPanel.css
        ├── BacklogPanel.tsx     # 백로그 패널
        ├── BacklogPanel.css
        ├── DetailPanel.tsx      # 상세 편집 패널
        ├── DetailPanel.css
        ├── RightPanel.tsx       # 우측 시스템 패널
        ├── RightPanel.css
        ├── SettingsPanel.tsx    # 설정 패널 (레이아웃/줌 설정)
        └── SettingsPanel.css
```

---

## 설계 원칙 준수 현황

| 원칙 | 상태 | 비고 |
|------|------|------|
| Canvas first | ✅ | SVG 기반 보드 중심 |
| Year first | ✅ | 12개월 전체 한 화면 |
| Zoom driven | ✅ | Z0~Z4 5단계 정보 밀도 |
| Range based | ✅ 기초 | 타입/저장/표시 구현, 생성 UX 미완 |
| Overlay based | ✅ 기초 | 타입/저장 구현, 배치/편집 미완 |
| Local first | 🔲 | Dexie 설치됨, 연동 미완 |
| Command based | ✅ | Zustand actions = commands |
| Minimal chrome | ✅ | 반투명 툴바, 패널 숨김 기본 |
| Mobile capable | ✅ 기초 | 핀치줌/터치 대응, 모바일 최적화 미완 |
| Portable data | 🔲 | Export/Import 미구현 |
